package com.demo.pdf.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Optional;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.pdf.entity.User;
import com.demo.pdf.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public ByteArrayInputStream generateExcel(Long userId) {
        // Create a workbook and a sheet
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("User Data");

            // Create a header row
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("ID");
            headerRow.createCell(1).setCellValue("Name");
            headerRow.createCell(2).setCellValue("Email");
            headerRow.createCell(3).setCellValue("Mobile");

            // Fetch user from repository
            Optional<User> optionalUser = userRepository.findById(userId);
            if (optionalUser.isPresent()) {
                User user = optionalUser.get();
                Row dataRow = sheet.createRow(1);
                dataRow.createCell(0).setCellValue(user.getId());
                dataRow.createCell(1).setCellValue(user.getName());
                dataRow.createCell(2).setCellValue(user.getEmail());
                dataRow.createCell(3).setCellValue(user.getMobile());
            } else {
                return null; // Return null if user not found
            }

            // Write the workbook to the output stream
            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Handle exceptions appropriately
        }
    }
}


//    public ByteArrayInputStream generatePdf(Long id) {
//        ByteArrayOutputStream out = new ByteArrayOutputStream();
//
//        try {
//            Optional<User> optionalUser = userRepository.findById(id);
//            if (optionalUser.isPresent()) {
//                User user = optionalUser.get();
//
//                // Create PdfWriter and PdfDocument
//                PdfWriter writer = new PdfWriter(out);
//                PdfDocument pdfDocument = new PdfDocument(writer);
//                
//                // Create the Document layout (iText document)
//                Document document = new Document(pdfDocument);
//
//                // Add Title and content
//                document.add(new Paragraph("Registration Details"));
//                document.add(new Paragraph(" ")); // Line break
//                document.add(new Paragraph("Name: " + user.getName()));
//                document.add(new Paragraph("Email: " + user.getEmail()));
//                document.add(new Paragraph("Mobile: " + user.getMobile()));
//
//                // Close the document
//                document.close();
//                System.out.println("PDF generated successfully."); // Log success
//            } else {
//                System.out.println("User not found with ID: " + id); // Log user not found
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace(); // Log exception details
//        }
//
//        return new ByteArrayInputStream(out.toByteArray());
//    }
    
    