package com.demo.pdf.controller;

import java.io.ByteArrayInputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.pdf.entity.User;
import com.demo.pdf.service.UserService;

@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/generate/excel")
    public ResponseEntity<byte[]> generateExcel(@RequestBody User user) {
        ByteArrayInputStream excelStream = userService.generateExcel(user.getId());

        // Check if the stream is null or has no data
        if (excelStream == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null); // User not found
        }

        // Read bytes from the InputStream
        byte[] excelBytes = excelStream.readAllBytes();

        if (excelBytes.length == 0) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null); // Handle empty Excel
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=user_data.xlsx");
        headers.add("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"); // Set the content type for Excel

        return new ResponseEntity<>(excelBytes, headers, HttpStatus.OK);
    }
}


//    @PostMapping("/generate")
//    public ResponseEntity<byte[]> generatePdf(@RequestBody User user) {
//        // Assuming the user ID is provided in the request body
//        ByteArrayInputStream pdfStream = userService.generatePdf(user.getId());
//
//        if (pdfStream == null) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null); // User not found
//        }
//
//        byte[] pdfBytes = pdfStream.readAllBytes(); // Read bytes from the InputStream
//
//        if (pdfBytes.length == 0) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null); // Handle empty PDF
//        }
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("Content-Disposition", "inline; filename=registration_details.pdf");
//        headers.add("Content-Type", "application/pdf"); // Set the content type for PDF
//
//        return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
//    }
    
   